package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Customer;
import services.CustomerServiceImpl;

@WebServlet("/admin/customer/edit")
public class EditCustomerController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	CustomerServiceImpl customerService = new CustomerServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String username = req.getParameter("username");
			if (username != null) {
				Customer customer = customerService.getCustomerByUsername(username);
				req.setAttribute("customerEdit", customer);
				req.getRequestDispatcher("/views/customer/edit.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer");
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String user = (String) req.getParameter("username");
			String pass = req.getParameter("password");
			String fullname = req.getParameter("fullname");
			int admin = Integer.parseInt(req.getParameter("admin"));
			String address = req.getParameter("address");
			String phone = req.getParameter("phone");
			Customer customer = new Customer(user, pass, fullname, address, phone, admin);
			customerService.updateCustomer(customer);
			req.getSession().setAttribute("msg", "Success with customer name: " + user);
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer");
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer/edit?username="
					+ req.getParameter("username"));
			e.printStackTrace();
		}
	}
}
