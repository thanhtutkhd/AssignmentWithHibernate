package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Category;
import services.CategoryServiceImpl;

@WebServlet("/admin/category/create")
public class CreateCategoryController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	CategoryServiceImpl categoryService = new CategoryServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			req.getRequestDispatcher("/views/category/create.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String name = req.getParameter("name");
			if (name == null || name.trim().isEmpty()) {
				req.setAttribute("errorName", "Name is empty");
				req.getRequestDispatcher("/views/category/create.jsp").forward(req, resp);
			} else {
				Category category = new Category();
				category.setName(name);
				int idCategory = categoryService.createCategory(category);
				if (idCategory > 0) {
					req.getSession().setAttribute("msg", "Success with id category: " + idCategory);
					resp.sendRedirect(getServletContext().getContextPath() + "/admin/category");

				}
			}
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/category/create");
			e.printStackTrace();
		}
	}
}
