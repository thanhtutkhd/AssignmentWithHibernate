package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Category;
import entities.Product;
import services.CategoryService;
import services.CategoryServiceImpl;
import services.ProductService;
import services.ProductServiceImpl;

@WebServlet("/admin/product/create")
public class CreateProductController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	ProductService productService = new ProductServiceImpl();
	CategoryService categoryService = new CategoryServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			req.setAttribute("categories", categoryService.getCategories());
			req.getRequestDispatcher("/views/product/create.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String name = req.getParameter("name");
			String idCategoryParram = req.getParameter("idCategory");
			String image = req.getParameter("image");
			float price = Float.parseFloat(req.getParameter("price"));
			if (name == null || name.trim().isEmpty()) {
				req.getSession().setAttribute("errorName", "Name is not empty");
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/product/create");
			} else {
				Product product = new Product();
				product.setName(name);
				product.setImage(image);
				product.setPrice(price);
				if (idCategoryParram != null && Integer.parseInt(idCategoryParram) > 0) {
					int idCategory = Integer.parseInt(idCategoryParram);
					Category category = categoryService.getCategoryById(idCategory);
					product.setCategory(category);
				}
				int idProduct = productService.createProduct(product);
				if (idProduct > 0) {
					req.getSession().setAttribute("msg", "Success with id product: " + idProduct);
					resp.sendRedirect(getServletContext().getContextPath() + "/admin/product");
				}
			}
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/product/create");
			e.printStackTrace();
		}
	}
}
