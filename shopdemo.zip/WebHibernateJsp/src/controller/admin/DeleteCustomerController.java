package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.CustomerServiceImpl;

@WebServlet("/admin/customer/delete")
public class DeleteCustomerController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	CustomerServiceImpl customerService = new CustomerServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String username = req.getParameter("username");
			if (username != null) {
				boolean delete = customerService.deleteCustomer(username);
				if (delete) {
					req.getSession().setAttribute("msg", "Success");
				} else {
					req.getSession().setAttribute("msg", "Fail");
				}
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer");
			}

		} catch (Exception e) {
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer");
		}
	}
}
