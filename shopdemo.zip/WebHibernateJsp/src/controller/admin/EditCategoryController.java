package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Category;
import services.CategoryServiceImpl;

@WebServlet("/admin/category/edit")
public class EditCategoryController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	CategoryServiceImpl categoryService = new CategoryServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String idCategory = req.getParameter("id");
			if (idCategory != null) {
				int id = Integer.parseInt(idCategory);
				Category category = categoryService.getCategoryById(id);
				req.getSession().setAttribute("categoryEdit", category);
				req.getRequestDispatcher("/views/category/edit.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/category");
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String id = req.getParameter("id");
			String name = req.getParameter("name");

			if (name == null || name.trim().isEmpty()) {
				req.setAttribute("errorName", "Name is empty");
				req.getRequestDispatcher("/views/category/edit.jsp").forward(req, resp);
			} else {
				Category category = new Category();
				category.setId(Integer.parseInt(id));
				category.setName(name);
				categoryService.updateCategory(category);
				req.getSession().setAttribute("msg", "Success with category name: " + name);
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/category");
			}
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/category/edit?id=" + req.getParameter("id"));
			e.printStackTrace();
		}
	}
}
