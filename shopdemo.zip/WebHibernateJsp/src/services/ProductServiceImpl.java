package services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import dao.ProductDao;
import entities.Product;
import ulti.HibernateUtil;

public class ProductServiceImpl implements ProductService {

	static final SessionFactory factory = HibernateUtil.getSessionFactory();
	private ProductDao productDao = new ProductDao();

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProduct() throws Exception {
		List<Product> categories = null;
		try {
			Session session = factory.openSession();
			categories = session.createQuery("FROM Product").list();
			session.close();
		} catch (Exception e) {
			throw e;
		}
		return categories;
	}

	@Override
	public boolean deleteProduct(int id) throws Exception {
		try {
			return productDao.deleteProduct(id);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public boolean updateProduct(Product productUpdate) throws Exception {
		try {
			Product product = productDao.findById(productUpdate.getId());
			product.setName(productUpdate.getName());
			product.setCategory(productUpdate.getCategory());
			product.setPrice(productUpdate.getPrice());
			return productDao.updateProduct(product);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Integer createProduct(Product productNew) throws Exception {
		try {
			return productDao.saveProduct(productNew);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Product getProductById(int id) throws Exception {
		try {
			return productDao.findById(id);
		} catch (Exception e) {
			throw e;
		}
	}
}
