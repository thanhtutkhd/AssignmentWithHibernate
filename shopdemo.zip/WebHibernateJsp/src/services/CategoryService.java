package services;

import java.util.List;

import entities.Category;

public interface CategoryService {
	
	List<Category> getCategories() throws Exception ;
	boolean deleteCategory(int id) throws Exception;
	boolean updateCategory(Category productUpdate) throws Exception ;
	Integer createCategory(Category productNew) throws Exception ;
	Category getCategoryById(int id) throws Exception ;
}
