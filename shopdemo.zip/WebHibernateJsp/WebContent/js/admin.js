$(document).ready(function(){
    removeNotification();
});