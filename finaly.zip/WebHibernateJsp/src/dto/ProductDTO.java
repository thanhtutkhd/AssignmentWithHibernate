package dto;

import java.io.Serializable;

import entities.Product;

public class ProductDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Product prod;
	private int quantity;

	public ProductDTO() {

	}

	public ProductDTO(Product prod) {
		this.prod = prod;
		this.quantity = 1;
	}

	public Product getProd() {
		return prod;
	}

	public void setProd(Product prod) {
		this.prod = prod;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
