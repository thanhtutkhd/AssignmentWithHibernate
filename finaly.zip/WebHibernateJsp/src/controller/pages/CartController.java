package controller.pages;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.ProductDTO;
import entities.Product;
import services.CartServiceImp;
import services.ProductServiceImpl;

@WebServlet("/CartController")
public class CartController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	ProductServiceImpl prodService = new ProductServiceImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String yc = request.getParameter("request");
		int idProduct = Integer.parseInt(request.getParameter("id"));
		String name = null;
		float price = 0;
		try {
			if (yc.equals("cart")) {
				HttpSession session = request.getSession(true);
				CartServiceImp shoppp = (CartServiceImp) session.getAttribute("SHOP");
				if (shoppp == null) {
					shoppp =  new CartServiceImp();
				}
				for (Product p : prodService.getListById(idProduct)) {
					name = p.getName();
					price = p.getPrice();
				}
				Product pr = new Product(idProduct, name, price);
				ProductDTO prdto = new ProductDTO(pr);
				shoppp.addSanPham(prdto);
				session.setAttribute("SHOP", shoppp);
				response.sendRedirect("index.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
