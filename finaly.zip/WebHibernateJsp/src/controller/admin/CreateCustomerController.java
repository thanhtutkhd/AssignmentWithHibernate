package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Customer;
import services.CustomerServiceImpl;

@WebServlet("/admin/customer/create")
public class CreateCustomerController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	CustomerServiceImpl customerService = new CustomerServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			req.setAttribute("customers", customerService.getAllCustomer());
			req.getRequestDispatcher("/views/customer/create.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String user = req.getParameter("username");
			String pass = req.getParameter("password");
			String fullname = req.getParameter("fullname");
			int admin = Integer.parseInt(req.getParameter("admin"));
			String address = req.getParameter("address");
			String phone = req.getParameter("phone");
			Customer customer = new Customer(user, pass, fullname, address, phone, admin);
			String check = customerService.createCustomer(customer);
			if (check != null) {
				req.getSession().setAttribute("msg", "Success with username customer: " + check);
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer");
			}
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/customer/create");
			e.printStackTrace();
		}
	}
}
