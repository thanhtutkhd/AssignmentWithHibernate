package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Category;
import entities.Product;
import services.CategoryService;
import services.CategoryServiceImpl;
import services.ProductServiceImpl;

@WebServlet("/admin/product/edit")
public class EditProductController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	ProductServiceImpl productService = new ProductServiceImpl();
	CategoryService categoryService = new CategoryServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			//get product to edit
			String idProduct = req.getParameter("id");
			if (idProduct != null) {
				int id = Integer.parseInt(idProduct);
				Product product = productService.getProductById(id);
				req.setAttribute("productEdit", product);
				req.setAttribute("categories", categoryService.getCategories());
				req.getRequestDispatcher("/views/product/edit.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(getServletContext().getContextPath() + "/admin/product");
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String id = req.getParameter("id");
			String name = req.getParameter("name");
			float price = Float.parseFloat(req.getParameter("price"));
			String idCategoryParram = req.getParameter("idCategory");

			if (name == null || name.trim().isEmpty()) {
				req.getSession().setAttribute("errorName", "Name is empty");
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/product/edit?id=" + id);
			} else {
				Product product = new Product();
				product.setId(Integer.parseInt(id));
				product.setName(name);
				product.setPrice(price);
				if (idCategoryParram != null && Integer.parseInt(idCategoryParram) > 0) {
					int idCategory = Integer.parseInt(idCategoryParram);
					Category category = categoryService.getCategoryById(idCategory);
					product.setCategory(category);
				}
				productService.updateProduct(product);
				req.getSession().setAttribute("msg", "Success with product name: " + name);
				resp.sendRedirect(getServletContext().getContextPath() + "/admin/product");
			}
		} catch (Exception e) {
			req.getSession().setAttribute("msg", e.getMessage());
			req.getSession().setAttribute("err", e.getCause().getMessage());
			resp.sendRedirect(
					getServletContext().getContextPath() + "/admin/product/edit?id=" + req.getParameter("id"));
			e.printStackTrace();
		}
	}
}
