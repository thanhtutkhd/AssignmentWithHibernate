package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import services.CustomerServiceImpl;

@WebServlet("/login")
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	CustomerServiceImpl customerService = new CustomerServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {		
		HttpSession session = request.getSession(true);
		session.removeAttribute("uCustomer");
		response.sendRedirect("index.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession(true);
			String action = request.getParameter("submit");
			if (action.equals("login")) {
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				int role = customerService.checkLogIn(username, password);
				if (role == 1) {
					session.setAttribute("uAdmin", username);
					response.sendRedirect("admin.jsp");
				} else if (role == 0) {
					session.setAttribute("uCustomer", username);
					response.sendRedirect("index.jsp");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
