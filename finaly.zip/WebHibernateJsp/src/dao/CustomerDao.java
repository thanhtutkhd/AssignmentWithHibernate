package dao;

import java.util.*;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import entities.Customer;

@SuppressWarnings("unchecked")
public class CustomerDao extends GenericDao {

	public List<Customer> getAllCustomer() {
		List<Customer> list = null;
		Transaction tx = null;
		Session session = null;
		try {
			session = getFactory().openSession();
			tx = session.beginTransaction();
			list = session.createQuery("FROM Customer").list();
			tx.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean deleteCustomer(String username) throws Exception {
		Session session = null;
		Transaction tx = null;
		try {
			session = getFactory().openSession();
			tx = session.beginTransaction();
			Query q = session.createQuery("Delete Customer c where c.username=:username");
			q.setParameter("username", username);
			q.executeUpdate();
			tx.commit();
			return true;
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
				tx = null;
			}
			throw e;
		} finally {
			session.close();
		}
	}

	public boolean updateCustomer(Customer customer) throws Exception {
		Session session = null;
		Transaction tx = null;
		try {
			session = getFactory().openSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(customer);
			tx.commit();

			return true;
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
				tx = null;
			}
			throw e;
		} finally {
			session.close();
		}
	}

	public String saveCustomer(Customer customerNew) throws Exception {
		Session session = null;
		Transaction tx = null;
		String username = null;
		try {
			session = getFactory().openSession();
			tx = session.beginTransaction();
			Customer customer = new Customer();
			customer.setUsername(customerNew.getUsername());
			customer.setPassword(customerNew.getPassword());
			customer.setFullname(customerNew.getFullname());
			customer.setAdmin(customerNew.getAdmin());
			customer.setAddress(customerNew.getAddress());
			customer.setPhone(customerNew.getPhone());
			username = (String) session.save(customer);
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
				tx = null;
			}
			throw e;
		} finally {
			session.close();
		}
		return username;
	}

	public Customer getCustomerByUsername(String username) throws Exception {
		Session session = null;
		Transaction tx = null;
		try {
			session = getFactory().openSession();
			tx = session.beginTransaction();
			Query q = session.createQuery("FROM Customer c where c.username=:username");
			q.setParameter("username", username);
			List<Customer> customer = (List<Customer>) q.list();
			if (customer != null) {
				return customer.get(0);
			}
			tx.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static int checkLogIn(String userName, String passWord) {
		int role = -1;
		List<Customer> list = null;
		Session session = getFactory().openSession();
		session.beginTransaction();
		String sql = " From Customer where username = '" + userName + "' and password = '" + passWord + "'";
		Query query = session.createQuery(sql);
		list = query.list();
		if (list.size() > 0) {
			for (Customer x : list) {
				return role = x.getAdmin();
			}
		}
		session.close();
		return role;

	}
}
