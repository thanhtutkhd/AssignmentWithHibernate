package dao;

import java.util.HashMap;

import dto.ProductDTO;

@SuppressWarnings("rawtypes")
public class CartDao extends HashMap {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public void addSanPham(ProductDTO sp) {
		int key = sp.getProd().getId();
		if (this.containsKey(key)) {
			int oldQuantity = ((ProductDTO) this.get(key)).getQuantity();
			((ProductDTO) this.get(key)).setQuantity(oldQuantity + 1);
		} else {
			this.put(sp.getProd().getId(), sp);
		}
	}

	public boolean removeSanPham(String code) {
		if (this.containsKey(code)) {
			this.remove(code);
			return true;
		}
		return false;
	}

	public int countItem() {
		int count = 0;
		count = this.size();
		return count;
	}

}
