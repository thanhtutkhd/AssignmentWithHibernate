package services;

import java.util.List;

import dao.CategoryDao;
import entities.Category;

public class CategoryServiceImpl implements CategoryService {

	private CategoryDao categoryDao = new CategoryDao();

	@Override
	public List<Category> getCategories() throws Exception {
		try {
			return categoryDao.getAllCategories();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public boolean deleteCategory(int id) throws Exception {
		try {
			return categoryDao.deleteCategory(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public boolean updateCategory(Category categoryUpdate) throws Exception {
		try {
			Category category = categoryDao.findById(categoryUpdate.getId());
			category.setName(categoryUpdate.getName());
			category.setProducts(categoryUpdate.getProducts());
			return categoryDao.updateCategory(category);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Integer createCategory(Category categoryNew) throws Exception {
		try {
			return categoryDao.saveCategory(categoryNew);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Category getCategoryById(int id) throws Exception {
		try {
			return categoryDao.findById(id);
		} catch (Exception e) {
			throw e;
		}
	}

}
