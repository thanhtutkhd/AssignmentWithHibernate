package services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import dao.CustomerDao;
import entities.Customer;
import ulti.HibernateUtil;

@SuppressWarnings("unchecked")
public class CustomerServiceImpl implements CustomerService {

	static final SessionFactory factory = HibernateUtil.getSessionFactory();
	private CustomerDao customerDao = new CustomerDao();

	@Override
	public List<Customer> getAllCustomer() throws Exception {
		List<Customer> listCustomer = null;
		try {
			Session session = factory.openSession();
			listCustomer = session.createQuery("FROM Customer").list();
			session.close();
		} catch (Exception e) {
			throw e;
		}
		return listCustomer;
	}

	@Override
	public boolean deleteCustomer(String username) throws Exception {
		try {
			return customerDao.deleteCustomer(username);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public boolean updateCustomer(Customer customerUpdate) throws Exception {
		try {
			return customerDao.updateCustomer(customerUpdate);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public String createCustomer(Customer customerNew) throws Exception {
		try {
			return customerDao.saveCustomer(customerNew);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Customer getCustomerByUsername(String username) throws Exception {
		try {
			return customerDao.getCustomerByUsername(username);
		} catch (Exception e) {
			throw e;
		}
	}

	@SuppressWarnings("static-access")
	@Override
	public int checkLogIn(String userName, String passWord) throws Exception {
		try {
			return customerDao.checkLogIn(userName, passWord);
		} catch (Exception e) {
			throw e;
		}
	}

}
