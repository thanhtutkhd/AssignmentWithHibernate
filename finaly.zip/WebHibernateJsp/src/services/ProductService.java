package services;

import java.util.List;

import entities.Product;

public interface ProductService {
	
	List<Product> getAllProduct() throws Exception;
	List<Product> getListById(int id) throws Exception;
	boolean deleteProduct(int id) throws Exception;
	boolean updateProduct(Product productUpdate) throws Exception;
	Integer createProduct(Product productNew) throws Exception;
	Product getProductById(int id) throws Exception ;
}
