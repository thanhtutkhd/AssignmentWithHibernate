package services;

import dto.ProductDTO;

public interface CartService {

	void addSanPham(ProductDTO sp);

	boolean removeSanPham(String code);

}
