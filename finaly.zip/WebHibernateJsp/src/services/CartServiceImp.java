package services;

import dao.CartDao;
import dto.ProductDTO;

public class CartServiceImp implements CartService {
	CartDao cartDao = new CartDao();

	@Override
	public void addSanPham(ProductDTO sp) {
		cartDao.addSanPham(sp);
	}

	@Override
	public boolean removeSanPham(String code) {
		return cartDao.removeSanPham(code);
	}
}
