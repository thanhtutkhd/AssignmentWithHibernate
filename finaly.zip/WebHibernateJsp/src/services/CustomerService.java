package services;

import java.util.List;

import entities.Customer;

public interface CustomerService {

	List<Customer> getAllCustomer() throws Exception;

	boolean deleteCustomer(String username) throws Exception;

	boolean updateCustomer(Customer customerUpdate) throws Exception;

	String createCustomer(Customer customerNew) throws Exception;

	Customer getCustomerByUsername(String username) throws Exception;

	int checkLogIn(String userName, String passWord) throws Exception;
}
